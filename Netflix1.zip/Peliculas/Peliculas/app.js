// MODELO
const ModeloPeliculas = {
    obtenerPeliculas: function() {
        return JSON.parse(localStorage.getItem('mis_peliculas')) || [];
    },
    guardarPeliculas: function(peliculas) {
        localStorage.setItem('mis_peliculas', JSON.stringify(peliculas));
    },
    inicializarPeliculas: function() {
        let peliculas = this.obtenerPeliculas();
        if (peliculas.length === 0) {
            peliculas = [
                { titulo: "Superlópez", director: "Javier Ruiz Caldera", miniatura: "files/superlopez.png" },
                { titulo: "Jurassic Park", director: "Steven Spielberg", miniatura: "files/jurassicpark.png" },
                { titulo: "Interstellar", director: "Christopher Nolan", miniatura: "files/interstellar.png" }
            ];
            this.guardarPeliculas(peliculas);
        }
        return peliculas;
    }
};

// CONTROLADORES
// Controlador para inicializar la aplicación
const initContr = async () => {
    if (!localStorage.getItem('mis_peliculas')) {
        ModeloPeliculas.guardarPeliculas(ModeloPeliculas.inicializarPeliculas());
    }
    indexContr();
};

// Controlador para mostrar la vista principal con todas las películas
function indexContr() {
    const peliculas = ModeloPeliculas.obtenerPeliculas();
    indexView(peliculas);
}

// VISTAS
function indexView(peliculas) {
    const mainDiv = document.getElementById('main');
    mainDiv.innerHTML = `<h2>Mis Películas Favoritas</h2>`;
    mainDiv.innerHTML += `<button class="new">Añadir</button> <button class="reset">Reset</button>`;

    peliculas.forEach((pelicula, i) => {
        mainDiv.innerHTML += `
            <div class="movie-card">
                <img src="${pelicula.miniatura}" alt="Carátula de ${pelicula.titulo}">
                <h3>${pelicula.titulo}</h3>
                <p>Director: ${pelicula.director}</p>
                <button class="show" data-my-id="${i}">Ver</button>
                <button class="edit" data-my-id="${i}">Editar</button>
                <button class="delete" data-my-id="${i}">Borrar</button>
            </div>
        `;
    });
}

// ROUTER
document.addEventListener("click", function(event) {
    if (event.target.classList.contains("show")) {
        showContr(event.target.dataset.myId);
    } else if (event.target.classList.contains("new")) {
        newContr();
    } else if (event.target.classList.contains("create")) {
        createContr();
    } else if (event.target.classList.contains("edit")) {
        editContr(event.target.dataset.myId);
    } else if (event.target.classList.contains("update")) {
        updateContr(event.target.dataset.myId);
    } else if (event.target.classList.contains("delete")) {
        deleteContr(event.target.dataset.myId);
    } else if (event.target.classList.contains("reset")) {
        resetContr();
    } else if (event.target.classList.contains("index")) {
        indexContr();
    }
});

// Otras funciones de controladores y vistas
function newContr() {
    newView();
}

function newView() {
    document.getElementById('main').innerHTML = `
        <h2>Crear Película</h2>
        <form>
            <label>Título</label>
            <input type="text" id="newTitulo">
            <label>Director</label>
            <input type="text" id="newDirector">
            <label>Miniatura (URL)</label>
            <input type="text" id="newMiniatura">
            <button type="button" class="create">Crear</button>
            <button type="button" class="index">Volver</button>
        </form>
    `;
}

function createContr() {
    const titulo = document.getElementById('newTitulo').value;
    const director = document.getElementById('newDirector').value;
    const miniatura = document.getElementById('newMiniatura').value;

    if (titulo && director && miniatura) {
        const peliculas = ModeloPeliculas.obtenerPeliculas();
        peliculas.push({ titulo, director, miniatura });
        ModeloPeliculas.guardarPeliculas(peliculas);
        indexContr();
    } else {
        alert("Por favor, completa todos los campos.");
    }
}

function showContr(i) {
    const peliculas = ModeloPeliculas.obtenerPeliculas();
    const pelicula = peliculas[i];
    showView(pelicula);
}

function showView(pelicula) {
    document.getElementById('main').innerHTML = `
        <h2>Detalle de la Película</h2>
        <p>La película <strong>${pelicula.titulo}</strong> fue dirigida por <strong>${pelicula.director}</strong>!</p>
        <img src="${pelicula.miniatura}" alt="Carátula de ${pelicula.titulo}" style="width:150px;">
        <button class="index">Volver</button>
    `;
}

function editContr(i) {
    const peliculas = ModeloPeliculas.obtenerPeliculas();
    const pelicula = peliculas[i];
    editView(i, pelicula);
}

function editView(i, pelicula) {
    document.getElementById('main').innerHTML = `
        <h2>Editar Película</h2>
        <form>
            <label>Título</label>
            <input type="text" id="editTitulo" value="${pelicula.titulo}">
            <label>Director</label>
            <input type="text" id="editDirector" value="${pelicula.director}">
            <label>Miniatura (URL)</label>
            <input type="text" id="editMiniatura" value="${pelicula.miniatura}">
            <button type="button" class="update" data-my-id="${i}">Actualizar</button>
            <button type="button" class="index">Volver</button>
        </form>
    `;
}

function updateContr(i) {
    const titulo = document.getElementById('editTitulo').value;
    const director = document.getElementById('editDirector').value;
    const miniatura = document.getElementById('editMiniatura').value;

    if (titulo && director && miniatura) {
        const peliculas = ModeloPeliculas.obtenerPeliculas();
        peliculas[i] = { titulo, director, miniatura };
        ModeloPeliculas.guardarPeliculas(peliculas);
        indexContr();
    } else {
        alert("Por favor, completa todos los campos.");
    }
}

function deleteContr(i) {
    if (confirm("¿Seguro que deseas eliminar esta película?")) {
        const peliculas = ModeloPeliculas.obtenerPeliculas();
        peliculas.splice(i, 1); // Elimina la película en la posición i
        ModeloPeliculas.guardarPeliculas(peliculas);
        indexContr(); // Vuelve a la vista principal
    }
}

function resetContr() {
    const peliculas = ModeloPeliculas.inicializarPeliculas();
    ModeloPeliculas.guardarPeliculas(peliculas);
    indexContr(); // Vuelve a la vista principal con las películas iniciales
}

// Inicialización
document.addEventListener('DOMContentLoaded', initContr);

